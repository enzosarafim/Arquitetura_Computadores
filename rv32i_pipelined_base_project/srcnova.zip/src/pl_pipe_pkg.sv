// Definicoes dos registradores de pipeline -- processador RV32I pipelined

package pl_pipe_pkg;

    // IF/ID 
    typedef struct packed {
        logic [31:0] pc;
        logic [31:0] instr;
    } if_id_t;

    // ID/EX
    typedef struct packed {
        // sinais de controle propagados para os estagios seguintes
        logic        alu_src;
        logic [1:0]  alu_src_a; // operando A da ALU: 00=rs1, 01=PC, 10=zero
        logic        mem_to_reg;
        logic        reg_write;
        logic        mem_read;
        logic        mem_write;
        logic [1:0]  alu_op;
        logic        branch;
        logic        jump;      // JAL/JALR: rd = PC+4 e desvio incondicional
        logic        jump_reg;  // JALR: destino vem de rs1 + imm
        // dados
        logic [31:0] pc;
        logic [31:0] rd1;       // saida 1 do banco de registradores
        logic [31:0] rd2;       // saida 2 do banco de registradores
        logic [4:0]  rs1;       // endereco rs1 (para forwarding)
        logic [4:0]  rs2;       // endereco rs2 (para forwarding)
        logic [4:0]  rd;        // registrador destino
        logic [31:0] imm_ext;   // imediato com extensao de sinal
        logic [2:0]  funct3;
        logic [6:0]  funct7;
    } id_ex_t;

    // EX/MEM
    typedef struct packed {
        // sinais de controle
        logic        mem_to_reg;
        logic        reg_write;
        logic        mem_read;
        logic        mem_write;
        // dados
        logic [31:0] alu_result;  // resultado da ALU, ou PC+4 em JAL/JALR
        logic [31:0] write_data;  // valor de rs2 apos forwarding (para stores)
        logic [4:0]  rd;
        logic [2:0]  funct3;      // largura e sinal de loads/stores
    } ex_mem_t;

    // MEM/WB 
    typedef struct packed {
        // sinais de controle
        logic        mem_to_reg;
        logic        reg_write;
        // dados
        logic [31:0] alu_result;
        logic [31:0] read_data;   // dado lido da memoria, ja estendido (loads)
        logic [4:0]  rd;
    } mem_wb_t;

endpackage
